<?php

namespace common\grid;

interface GridModelActionsInterface
{
    public function actionAllowed($name);
}
