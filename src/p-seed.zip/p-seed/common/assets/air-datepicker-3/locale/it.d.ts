declare module 'air-datepicker/locale/it' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const it: AirDatepickerLocale;

    export default it;
}
