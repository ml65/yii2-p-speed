declare module 'air-datepicker/locale/ko' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const ko: AirDatepickerLocale;

    export default ko;
}
