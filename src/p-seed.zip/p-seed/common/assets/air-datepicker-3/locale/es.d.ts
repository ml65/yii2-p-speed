declare module 'air-datepicker/locale/es' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const es: AirDatepickerLocale;

    export default es;
}
