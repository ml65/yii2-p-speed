declare module 'air-datepicker/locale/sk' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const sk: AirDatepickerLocale;

    export default sk;
}
