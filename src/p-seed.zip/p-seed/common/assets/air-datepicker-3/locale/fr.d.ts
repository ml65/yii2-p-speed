declare module 'air-datepicker/locale/fr' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const fr: AirDatepickerLocale;

    export default fr;
}
