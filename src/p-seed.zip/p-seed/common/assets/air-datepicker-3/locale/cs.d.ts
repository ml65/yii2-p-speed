declare module 'air-datepicker/locale/cs' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const cs: AirDatepickerLocale;

    export default cs;
}
