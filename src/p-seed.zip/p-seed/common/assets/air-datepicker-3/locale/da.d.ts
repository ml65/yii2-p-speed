declare module 'air-datepicker/locale/da' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const da: AirDatepickerLocale;

    export default da;
}
